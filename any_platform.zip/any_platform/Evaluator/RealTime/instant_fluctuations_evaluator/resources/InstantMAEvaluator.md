Triggers systematically on a new candle. 

Uses the simple [moving average](https://www.investopedia.com/terms/m/movingaverage.asp) with a length of 6 to set its evaluation.