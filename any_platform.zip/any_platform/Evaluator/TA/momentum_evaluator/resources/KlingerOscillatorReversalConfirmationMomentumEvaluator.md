Uses [Klinger Oscillator](https://www.investopedia.com/terms/k/klingeroscillator.asp) with a short period of 35 and a long period of 55 to find reversals.

Returns True on reversal confirmation.