Binance is a SpotExchange adaptation for Binance exchange using the REST API. 
