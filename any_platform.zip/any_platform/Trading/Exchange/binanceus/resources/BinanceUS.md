BinanceUS is a SpotExchange adaptation for Binance US exchange using the REST API. 
