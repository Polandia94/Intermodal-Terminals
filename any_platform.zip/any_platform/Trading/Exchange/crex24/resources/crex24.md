Crex24 is a basic SpotExchange adaptation for Crex24 exchange. 
