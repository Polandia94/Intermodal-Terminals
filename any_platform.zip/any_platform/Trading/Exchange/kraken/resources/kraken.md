Kraken is a basic SpotExchange adaptation for Kraken exchange. 
