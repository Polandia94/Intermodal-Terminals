Okex is a basic SpotExchange adaptation for Okex exchange. 
