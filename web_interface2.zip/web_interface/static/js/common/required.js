// Functions required in each page


function init_tooltips() {
    $('[data-toggle="tooltip"]').tooltip();
}


$(document).ready(function() {
    init_tooltips();
});
